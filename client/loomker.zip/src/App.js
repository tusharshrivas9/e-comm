import React from 'react'
import Navbar from './Components/Navbar'
import Navbar2 from './Components/Navbar2'
import Carousal from './Pages/Carousal'
import Footer from './Components/Footer'

const App = () => {
  return (
    <>
     <Navbar/> 
     <Navbar2/>
     <Carousal/>
     <Footer/>
    </>
  )
}

export default App
