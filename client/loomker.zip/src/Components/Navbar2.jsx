import React from 'react'
import "../Components/Navbar.css"

const Navbar2 = () => {
  return (
    <>
      <nav>
      <div className="container">

      <div style={{backgroundColor:"#F4F4F4"}} className="container-fluid d-flex justify-content-center">

        <ul className='d-flex list-unstyled'>
            <li className='mx-3'>Home</li>
            <li className='mx-3'>Products</li>
            <li className='mx-3'>About us</li>
            <li className='mx-3'>Contact us</li>
        </ul>
      </div>
      </div>
      </nav>
    </>
  )
}

export default Navbar2
