import navicn from "../images/nav-icn.png";
import user from "../images/user.svg";
import cart from "../images/shopping-cart.svg";
import carsoul from "../images/carousal1.png";
import frsme from "../images/Frame 47.png"

// item2 images is here


import p1 from "../images/loom1.png";
import p2 from "../images/loom2.png";
import p3 from "../images/loom3.png";
import p4 from "../images/loom4.png";
import man from "../images/manwork.png";

// owner image
import owner from "../images/owner.png";

//svg images like truck earphonne pen ...

import truck from "../images/truck.svg";
import pen from "../images/magicpen.svg";
import money from "../images/money.svg";
import head from "../images/headphone.svg";
import arrowleft from "../images/left.svg";
import arrowright from "../images/right.svg"
import footer from "../images/footer.png"




const images = {
 nav_bar : navicn,
 profile_icn : user,
 shopping : cart,
 carsol : carsoul,
 Fram : frsme,
 loom1 : p1,
 loom2 : p2,
 loom3 : p3,
 loom4 : p4,
 manwork : man,
 owner : owner,
 truck : truck,
 pen : pen,
 money : money,
 head : head,
 left : arrowleft,
 right : arrowright ,
 foo : footer

}

export default images
