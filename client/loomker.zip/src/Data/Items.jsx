import k1 from "../images/kurti1.png"
import k2 from "..//images/kurti2.png";
import k3 from "..//images/kurti3.png";
import k4 from "..//images/kurti4.png";



const itemData = [
    {
        id:"1",
        name:"Kurti 1",
        photo:k1,
        cost :"Rs 1200"
    },
    {
        id:"2",
        name:"Kurti 2",
        photo:k2,
        cost :"Rs 1200"
    },
    {
        id:"3",
        name:"Kurti 3",
        photo:k3,
        cost :"Rs 1200"
    },
    {
        id:"4",
        name:"Kurti 4",
        photo:k4,
        cost :"Rs 1200"
    },
    


    {
        id:"5",
        name:"Kurti 1",
        photo:k4,
        cost :"Rs 1200"
    },
    {
        id:"2",
        name:"Kurti 2",
        photo:k3,
        cost :"Rs 1200"
    },
    {
        id:"3",
        name:"Kurti 3",
        photo:k2,
        cost :"Rs 1200"
    },
    {
        id:"4",
        name:"Kurti 4",
        photo:k1,
        cost :"Rs 1200"
    },
    
]

export default itemData;