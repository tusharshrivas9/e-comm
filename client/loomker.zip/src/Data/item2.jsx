import images from "../Data/Images"






      const dataTwo = [ {
        id:"1",
        name:"Kurti 1",
        photo:images.loom1,
        cost :"Rs 1200"
    },
    {
        id:"2",
        name:"Kurti 2",
        photo:images.loom2,
        cost :"Rs 1200"
    },
    {
        id:"3",
        name:"Kurti 3",
        photo:images.loom3,
        cost :"Rs 1200"
    },
    {
        id:"4",
        name:"Kurti 4",
        photo:images.loom4,
        cost :"Rs 1200"
    },
    

    {
        id:"1",
        name:"Kurti 1",
        photo:images.loom2,
        cost :"Rs 1200"
    },
    {
        id:"2",
        name:"Kurti 2",
        photo:images.loom1,
        cost :"Rs 1200"
    },
    {
        id:"3",
        name:"Kurti 3",
        photo:images.loom4,
        cost :"Rs 1200"
    },
    {
        id:"4",
        name:"Kurti 4",
        photo:images.loom3,
        cost :"Rs 1200"
    },



      ]
  

export default dataTwo
